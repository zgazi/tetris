#tetris

from pygame import *
from random import *
init()
from pprint import *

width,height=800,600
screen=display.set_mode((width,height))
display.set_caption("Tetris")
GREY=(127,127,127)
BLACK=(0,0,0)
IBLOCK=(52,235,229)
JBLOCK=(28,96,199)
LBLOCK=(255,132,0)
OBLOCK=(242,242,65)
SBLOCK=(71,214,116)
ZBLOCK=(235,9,9)
TBLOCK=(136,0,255)
WHITE=(255,255,255)
myClock=time.Clock()
running=True

shapes=[[[0,0,0,0,0], #I block
        [1,1,1,1,0]],

        [[2,0,0],   #J block
         [2,2,2]],

        [[0,0,3],   #L block
         [3,3,3]],

        [[4,4],     #O block
         [4,4]],

        [[0,5,5],   #S block
         [5,5,0]],

        [[6,6,0],   #Z block
         [0,6,6]],

        [[0,7,0],   #T block
         [7,7,7]]]

cols=[IBLOCK,JBLOCK,LBLOCK,OBLOCK,SBLOCK,ZBLOCK,TBLOCK]

mainlist=[[-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,0,0,0,0,0,0,0,0,0,0,-1],
          [-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,]]


def menu():

    running=True

    background=image.load("background.png")
    background=transform.scale(background,(800,600))

    onescoreback=image.load("1highscorebackground.png")
    onescoreback=transform.scale(onescoreback,(207,20))
    twoscoreback=image.load("2highscorebackground.png")
    twoscoreback=transform.scale(twoscoreback,(207,20))
    
    playrect=Rect(304,208,193,52)
    levelrect=Rect(314,270,173,45)
    settingsrect=Rect(279,497,62,52)
    howtoplayrect=Rect(352,497,63,52)
    moregamesrect=Rect(427,493,94,60)
    
    while running:

        screen.blit(background,(0,0))

        mx,my=mouse.get_pos()
        mb=mouse.get_pressed()
        
        for evt in event.get():
            if evt.type==QUIT:
                running=False
            
            if howtoplayrect.collidepoint(mx,my):
                if evt.type==MOUSEBUTTONDOWN:
                    if evt.button==1:
                        return "howtoplay"
            if playrect.collidepoint(mx,my):
                if evt.type==MOUSEBUTTONDOWN:
                    if evt.button==1:
                        return "play"

        for i in range(3):
            screen.blit(onescoreback,(300,357+(47*i)))
        for i in range(2):
            screen.blit(twoscoreback,(300,379+(47*i)))
      
        myClock.tick(60)
        display.flip()


def howtoplay():

    running=True

    howtoplayshow=image.load("howtoplayfinal.png")
    howtoplayshow=transform.scale(howtoplayshow,(800,600))

    donerect=Rect(353,514,93,44)

    while running:
        for evt in event.get():
            if evt.type==QUIT:
                running=False
            if evt.type==MOUSEBUTTONDOWN:
                if evt.button==1:
                    if donerect.collidepoint(mx,my):
                        return "menu"
                    

        screen.blit(howtoplayshow,(0,0))
                       
        mx,my=mouse.get_pos()
        mb=mouse.get_pressed()
      
        myClock.tick(60)
        display.flip()

def fixate(mainlist):
    for i in range(len(mainlist)):
        for j in range(len(mainlist[i])):
            if mainlist[i][j]==1:
                mainlist[i][j]=10
            if mainlist[i][j]==2:
                mainlist[i][j]=20
            if mainlist[i][j]==3:
                mainlist[i][j]=30
            if mainlist[i][j]==4:
                mainlist[i][j]=40
            if mainlist[i][j]==5:
                mainlist[i][j]=50
            if mainlist[i][j]==6:
                mainlist[i][j]=60
            if mainlist[i][j]==7:
                mainlist[i][j]=70
                
    return mainlist

def playbg():
    playbg=image.load("playbg.png")
    playbg=transform.scale(playbg,(116,23))
    for pos in range(3):
        screen.blit(playbg,(85,383+(pos*60)))


def order(shapes,ordrlist):
    if len(ordrlist)<4:
        ordrlist.append(shapes[randint(0,6)])
    return ordrlist


def activepiece(ordrlist):
    activepiec=ordrlist.pop(0)
    return activepiec


def createpiece(activepiece,mainlist,background):
    for i in range(len(activepiece)):
        for j in range(len(activepiece[0])):
            mainlist[i][4+j]=activepiece[i][j]
    return mainlist


def godown(mainlist,count):
    if count[0]%2==1:
        for i in range(len(mainlist)-1,-1,-1):
            for j in range(len(mainlist[i])):
                if 9>mainlist[i][j]>0 and mainlist[i+1][j]==0:
                    mainlist[i+1][j]=mainlist[i][j]
                    mainlist[i][j]=0
                
    count[0]+=1

def stopgodown(mainlist):
    for i in range(len(mainlist)-1,-1,-1):
        for j in range(len(mainlist[i])):
            if 0<mainlist[i][j]<9:
                if mainlist[i+1][j]==-1 or mainlist[i+1][j]>9:
                    return False
    return True


def drawshapes(mainlist):
    for i in range(21):
        for j in range(12):
            if 9>mainlist[i][j]>0:
                draw.rect(screen,cols[mainlist[i][j]-1],(246+(j*25)+j,40+(i*25)+i,25,25))
            if mainlist[i][j]>=10:
                draw.rect(screen,cols[int(mainlist[i][j]/10-1)],(246+(j*25)+j,40+(i*25)+i,25,25))

def move(mainlist,direction):
    moveable=True
    for i in range(len(mainlist)):
        for j in range(len(mainlist[i])):
            if 0<mainlist[i][j]<9:
                if mainlist[i][j+1]!=0 or mainlist[i][j-1]!=0:
                    moveable=False
    if moveable==True:
        if direction=="right":
            for i in range(len(mainlist)):
                for j in range(len(row)-1,-1,-1):
                    if 0<mainlist[i][j]<9:
                        mainlist[i][j+1]=mainlist[i][j]
                        mainlist[i][j]=0
        if direction=="left":
            for i in range(1,len(mainlist)):
                for j in range(len(row)):
                    if 0<mainlist[i][j]<9:
                        mainlist[i][j-1]=mainlist[i][j]
                        mainlist[i][j]=0
    return mainlist


def play(shapes,mainlist):
    running=True
    active=False
    stop=False

    background=image.load("playingbackground.png")
    background=transform.scale(background,(800,600))

    ordrlist=[shapes[randint(0,6)] for i in range(4)]

    for i in range(1,4):
        screen.blit(transform.scale(image.load(f"{i}count.png"),(800,600)),(0,0))
        playbg()
        display.flip()
        time.wait(1000)

    count=[0]

    while running:
        for evt in event.get():
            if evt.type==QUIT:
                running=False
        
        screen.blit(background,(0,0))

        ordrlist=order(shapes,ordrlist)
        if active==False:
            activepiec=activepiece(ordrlist)
            mainlist=createpiece(activepiec,mainlist,background)
            active=True
        if active==True:
            stop=stopgodown(mainlist)
            if stop==True:
                godown(mainlist,count)
                keys = key.get_pressed()
                if keys[K_LEFT]:
                    mainlist=move(mainlist,"left")
                elif keys[K_RIGHT]:
                    mainlist=move(mainlist,"right")
            else:
                mainlist=fixate(mainlist)
                active=False

        pprint(mainlist)
        screen.blit(background,(0,0))
        playbg()
        drawshapes(mainlist)

        mx,my=mouse.get_pos()
        mb=mouse.get_pressed()
      
        myClock.tick(60)
        display.flip()

    
area="menu"   
while True:
    if area=="menu":
        area=menu()
    if area=="howtoplay":
        area=howtoplay()
    if area=="play":
        area=play(shapes,mainlist)
quit()
