from pygame import *
from random import *
init()
from pprint import *

width, height = 800, 600
screen = display.set_mode((width, height))
display.set_caption("Tetris")
GREY = (127, 127, 127)
BLACK = (0, 0, 0)
IBLOCK = (52, 235, 229)
JBLOCK = (28, 96, 199)
LBLOCK = (255, 132, 0)
OBLOCK = (242, 242, 65)
SBLOCK = (71, 214, 116)
ZBLOCK = (235, 9, 9)
TBLOCK = (136, 0, 255)
WHITE = (255, 255, 255)
myClock = time.Clock()
running = True

shapes = [
    [[0, 0, 0, 0, 0],  # I block
     [1, 1, 1, 1, 0]],

    [[2, 0, 0],  # J block
     [2, 2, 2]],

    [[0, 0, 3],  # L block
     [3, 3, 3]],

    [[4, 4],  # O block
     [4, 4]],

    [[0, 5, 5],  # S block
     [5, 5, 0]],

    [[6, 6, 0],  # Z block
     [0, 6, 6]],

    [[0, 7, 0],  # T block
     [7, 7, 7]]
]

cols = [IBLOCK, JBLOCK, LBLOCK, OBLOCK, SBLOCK, ZBLOCK, TBLOCK]

# 21 rows and 12 columns with border -1 on left and right and bottom
mainlist = [
    [-1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1] for _ in range(20)
] + [[-1] * 12]


def menu():

    running = True

    background = image.load("background.png")
    background = transform.scale(background, (800, 600))

    onescoreback = image.load("1highscorebackground.png")
    onescoreback = transform.scale(onescoreback, (207, 20))
    twoscoreback = image.load("2highscorebackground.png")
    twoscoreback = transform.scale(twoscoreback, (207, 20))

    playrect = Rect(304, 208, 193, 52)
    levelrect = Rect(314, 270, 173, 45)
    settingsrect = Rect(279, 497, 62, 52)
    howtoplayrect = Rect(352, 497, 63, 52)
    moregamesrect = Rect(427, 493, 94, 60)

    while running:

        screen.blit(background, (0, 0))

        mx, my = mouse.get_pos()
        mb = mouse.get_pressed()

        for evt in event.get():
            if evt.type == QUIT:
                running = False

            if howtoplayrect.collidepoint(mx, my):
                if evt.type == MOUSEBUTTONDOWN:
                    if evt.button == 1:
                        return "howtoplay"
            if playrect.collidepoint(mx, my):
                if evt.type == MOUSEBUTTONDOWN:
                    if evt.button == 1:
                        return "play"

        for i in range(3):
            screen.blit(onescoreback, (300, 357 + (47 * i)))
        for i in range(2):
            screen.blit(twoscoreback, (300, 379 + (47 * i)))

        myClock.tick(60)
        display.flip()


def howtoplay():

    running = True

    howtoplayshow = image.load("howtoplayfinal.png")
    howtoplayshow = transform.scale(howtoplayshow, (800, 600))

    donerect = Rect(353, 514, 93, 44)

    while running:
        for evt in event.get():
            if evt.type == QUIT:
                running = False
            if evt.type == MOUSEBUTTONDOWN:
                if evt.button == 1:
                    mx, my = mouse.get_pos()
                    if donerect.collidepoint(mx, my):
                        return "menu"

        screen.blit(howtoplayshow, (0, 0))

        mx, my = mouse.get_pos()
        mb = mouse.get_pressed()

        myClock.tick(60)
        display.flip()


def fixate(mainlist):
    for i in range(len(mainlist)):
        for j in range(len(mainlist[i])):
            if mainlist[i][j] == 1:
                mainlist[i][j] = 10
            if mainlist[i][j] == 2:
                mainlist[i][j] = 20
            if mainlist[i][j] == 3:
                mainlist[i][j] = 30
            if mainlist[i][j] == 4:
                mainlist[i][j] = 40
            if mainlist[i][j] == 5:
                mainlist[i][j] = 50
            if mainlist[i][j] == 6:
                mainlist[i][j] = 60
            if mainlist[i][j] == 7:
                mainlist[i][j] = 70

    return mainlist


def playbg():
    playbg_img = image.load("playbg.png")
    playbg_img = transform.scale(playbg_img, (116, 23))
    for pos in range(3):
        screen.blit(playbg_img, (85, 383 + (pos * 60)))


def order(shapes, ordrlist):
    if len(ordrlist) < 4:
        ordrlist.append(shapes[randint(0, 6)])
    return ordrlist


def can_move(mainlist, shape, x, y):
    """Check if the shape can be placed at position (x,y) on mainlist."""
    shape_height = len(shape)
    shape_width = len(shape[0])
    for i in range(shape_height):
        for j in range(shape_width):
            if shape[i][j] != 0:
                new_x = x + j
                new_y = y + i
                # Check bounds
                if new_y >= len(mainlist) or new_x < 0 or new_x >= len(mainlist[0]):
                    return False
                # Check collision with fixed blocks or borders
                if mainlist[new_y][new_x] >= 10 or mainlist[new_y][new_x] == -1:
                    return False
    return True


def place_shape(mainlist, shape, x, y):
    """Place shape on mainlist at position (x,y) with values 1-7."""
    # Clear any current active piece positions (values 1-7)
    for i in range(len(mainlist)):
        for j in range(len(mainlist[0])):
            if 0 < mainlist[i][j] < 10:
                mainlist[i][j] = 0

    shape_height = len(shape)
    shape_width = len(shape[0])
    for i in range(shape_height):
        for j in range(shape_width):
            if shape[i][j] != 0:
                mainlist[y + i][x + j] = shape[i][j]
    return mainlist


def drawshapes(mainlist):
    for i in range(21):
        for j in range(12):
            if 0 < mainlist[i][j] < 10:
                draw.rect(screen, cols[mainlist[i][j] - 1], (246 + (j * 25) + j, 40 + (i * 25) + i, 25, 25))
            if mainlist[i][j] >= 10:
                draw.rect(screen, cols[int(mainlist[i][j] / 10 - 1)], (246 + (j * 25) + j, 40 + (i * 25) + i, 25, 25))


def activepiece(ordrlist):
    return ordrlist.pop(0)

def play(shapes, mainlist):
    running = True
    active = False
    background = image.load("playingbackground.png")
    background = transform.scale(background, (800, 600))

    ordrlist = [shapes[randint(0, 6)] for _ in range(4)]

    for i in range(1, 4):
        screen.blit(transform.scale(image.load(f"{i}count.png"), (800, 600)), (0, 0))
        playbg()
        display.flip()
        time.wait(1000)

    count = [0]

    # Starting position for active piece (x is column, y is row)
    active_x = 4
    active_y = 0
    active_piece = None

    fall_time = 0
    fall_speed = 500  # milliseconds per drop

    move_left = False
    move_right = False
    move_delay = 150  # milliseconds between repeated moves
    move_timer = 0

    while running:
        dt = myClock.tick(60)
        fall_time += dt
        move_timer += dt

        for evt in event.get():
            if evt.type == QUIT:
                running = False

            elif evt.type == KEYDOWN:
                if evt.key == K_LEFT:
                    move_left = True
                if evt.key == K_RIGHT:
                    move_right = True

            elif evt.type == KEYUP:
                if evt.key == K_LEFT:
                    move_left = False
                if evt.key == K_RIGHT:
                    move_right = False

        screen.blit(background, (0, 0))

        ordrlist = order(shapes, ordrlist)
        if not active:
            active_piece = activepiece(ordrlist)
            active_x = 4
            active_y = 0
            if not can_move(mainlist, active_piece, active_x, active_y):
                # Game over
                print("Game Over!")
                running = False
                continue
            mainlist = place_shape(mainlist, active_piece, active_x, active_y)
            active = True

        # Move left/right on key hold with delay
        if move_left and move_timer > move_delay:
            if can_move(mainlist, active_piece, active_x - 1, active_y):
                active_x -= 1
                mainlist = place_shape(mainlist, active_piece, active_x, active_y)
            move_timer = 0

        if move_right and move_timer > move_delay:
            if can_move(mainlist, active_piece, active_x + 1, active_y):
                active_x += 1
                mainlist = place_shape(mainlist, active_piece, active_x, active_y)
            move_timer = 0

        # Automatic downward movement
        if fall_time > fall_speed:
            if can_move(mainlist, active_piece, active_x, active_y + 1):
                active_y += 1
                mainlist = place_shape(mainlist, active_piece, active_x, active_y)
            else:
                mainlist = fixate(mainlist)
                active = False
            fall_time = 0

        drawshapes(mainlist)
        playbg()

        display.flip()

    return "menu"


area = "menu"
while True:
    if area == "menu":
        area = menu()
    if area == "howtoplay":
        area = howtoplay()
    if area == "play":
        area = play(shapes, mainlist)
quit()
